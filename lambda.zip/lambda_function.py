import boto3
import os
from PIL import Image
from io import BytesIO

s3 = boto3.client('s3')
dest_bucket = os.environ['DEST_BUCKET']

def lambda_handler(event, context):
    for record in event['Records']:
        src_bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        response = s3.get_object(Bucket=src_bucket, Key=key)
        image = Image.open(BytesIO(response['Body'].read()))
        image = image.resize((128, 128))

        buffer = BytesIO()
        image.save(buffer, 'JPEG')
        buffer.seek(0)

        dest_key = f"resized/{key.split('/')[-1]}"
        s3.put_object(Bucket=dest_bucket, Key=dest_key, Body=buffer)
